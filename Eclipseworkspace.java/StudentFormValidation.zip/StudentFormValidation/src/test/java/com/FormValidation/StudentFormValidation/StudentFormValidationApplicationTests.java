package com.FormValidation.StudentFormValidation;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StudentFormValidationApplicationTests {

	@Test
	void contextLoads() {
	}

}

package com.simplespringboot.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FirstWebpageApplication {

	public static void main(String[] args) {
		SpringApplication.run(FirstWebpageApplication.class, args);
	}

}
